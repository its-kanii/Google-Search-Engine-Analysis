# import packages
import pandas as pd
from pytrends.request import TrendReg
import matplotlib.pyplot as plt
trends=TrendReq
