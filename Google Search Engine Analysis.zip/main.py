# GOOGLE SEARCH ANALYSIS
pytrends.build_payload(kw_list['Data Science'])
data=pytrends.interest_by_region()
data=data.sort_values(by='Data Science,ascending=False) 
data=data.head(10)
print(data)

  